#!/usr/bin/python
def hello():
    print 'Hello world!'
